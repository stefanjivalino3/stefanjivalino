<div class="gototop js-top">
	<a href="#" class="js-gotop"><i class="icon-arrow-up22"></i></a>
</div>
<!-- jQuery -->
<script src="<?php echo base_url(); ?>/assets/js/jquery.min.js"></script>
<!-- jQuery Easing -->
<script src="<?php echo base_url(); ?>/assets/js/jquery.easing.1.3.js"></script>
<!-- Bootstrap -->
<script src="<?php echo base_url(); ?>/assets/js/bootstrap.min.js"></script>
<!-- Waypoints -->
<script src="<?php echo base_url(); ?>/assets/js/jquery.waypoints.min.js"></script>
<!-- Stellar Parallax -->
<script src="<?php echo base_url(); ?>/assets/js/jquery.stellar.min.js"></script>
<!-- Easy PieChart -->
<script src="<?php echo base_url(); ?>/assets/js/jquery.easypiechart.min.js"></script>
<!-- Google Map -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCefOgb1ZWqYtj7raVSmN4PL2WkTrc-KyA&sensor=false"></script>
<script src="<?php echo base_url(); ?>/assets/js/google_map.js"></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugin/ckeditor/ckeditor.js'></script>  
	
<!-- Main -->
<script src="<?php echo base_url(); ?>/assets/js/main.js"></script>


